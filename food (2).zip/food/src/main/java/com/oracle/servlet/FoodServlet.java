package com.oracle.servlet;

import com.oracle.service.FoodService;
import com.oracle.service.FoodServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/foodServlet")
public class FoodServlet extends HttpServlet {

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    FoodService foodService = new FoodServiceImpl();
    req.setAttribute("foodList",foodService.selectFood());
    req.getRequestDispatcher("/list.jsp").forward(req,resp);
  }
}
