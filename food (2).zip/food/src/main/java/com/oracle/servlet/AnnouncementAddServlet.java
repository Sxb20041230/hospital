package com.oracle.servlet;

import com.oracle.pojo.Announcement;
import com.oracle.pojo.Food;
import com.oracle.service.FoodService;
import com.oracle.service.FoodServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@WebServlet("/announcementAddServlet")
public class AnnouncementAddServlet extends HttpServlet {

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    req.setCharacterEncoding("utf-8");
    String content = req.getParameter("content");
    String title = req.getParameter("title");
    String creator = req.getParameter("creator");
    Date date = new Date();
    String sdate = date.toString();
    Announcement announcement = new Announcement();
    announcement.setAnnouncement_id(null);
    announcement.setContent(content);
    announcement.setCreator(creator);
    announcement.setTitle(title);
    announcement.setCreation_time(sdate);
    FoodService foodService = new FoodServiceImpl();
    foodService.insertAnnouncement(announcement);
    resp.sendRedirect(req.getContextPath()+"/selectAnnouncementServlet");
  }
}
