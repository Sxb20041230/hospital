package com.oracle.servlet;

import com.github.pagehelper.PageInfo;
import com.oracle.pojo.Food;
import com.oracle.service.FoodService;
import com.oracle.service.FoodServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/foodListServlet")
public class FoodListServlet extends HttpServlet {

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    // 获取请求参数pageNum
    String strPageNum = req.getParameter("pageNum");

    // 默认设置pageNum为1，设置每页显示的记录数为4
    Integer pageNum = 1;
    Integer pageSize = 4;

    // 如果请求参数中包含pageNum，则进行转换
    if (strPageNum != null && !"".equals(strPageNum)){
      pageNum = Integer.parseInt(strPageNum);
    }

    // 创建FoodService实例
    FoodService foodService = new FoodServiceImpl();

    // 调用selectAllFood方法获取分页信息
    PageInfo<Food> pageInfo = foodService.selectAllFood(pageNum, pageSize);

    // 将食物列表存储到request中
    req.setAttribute("foodList", pageInfo.getList());
    System.out.println(pageInfo.getList());

    // 将分页信息存储到request中
    req.setAttribute("pageInfo", pageInfo);

    // 通过请求转发跳转到list.jsp页面
    req.getRequestDispatcher("/list.jsp").forward(req, resp);
  }
}
