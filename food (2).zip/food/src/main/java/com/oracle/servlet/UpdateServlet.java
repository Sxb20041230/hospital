package com.oracle.servlet;

import com.oracle.pojo.Food;
import com.oracle.service.FoodService;
import com.oracle.service.FoodServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/updateServlet")
public class UpdateServlet extends HttpServlet {

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    // 设置请求编码为UTF-8
    req.setCharacterEncoding("utf-8");

    // 获取请求参数
    String bid = req.getParameter("bid");
    String name = req.getParameter("name");
    Integer price = Integer.parseInt(req.getParameter("price"));
    String type = req.getParameter("type");

    // 创建食物对象并设置属性
    Food food = new Food();
    food.setBid(bid);
    food.setName(name);
    food.setPrice(price);
    food.setType(type);

    // 输出食物对象信息
    System.out.println(food);

    // 创建FoodService实例
    FoodService foodService = new FoodServiceImpl();

    // 调用FoodService的updateFood方法更新食物信息
    foodService.updateFood(food);
  }
}
