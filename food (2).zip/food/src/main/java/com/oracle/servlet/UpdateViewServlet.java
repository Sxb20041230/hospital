package com.oracle.servlet;

import com.oracle.pojo.Food;
import com.oracle.service.FoodService;
import com.oracle.service.FoodServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/updateViewServlet")
public class UpdateViewServlet extends HttpServlet {

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String bid = req.getParameter("bid");
    FoodService foodService = new FoodServiceImpl();
    Food food = foodService.selectAFood(bid);
    req.setAttribute("food",food);
    req.getRequestDispatcher("/update.jsp").forward(req,resp);
  }
}
