package com.oracle.pojo;
public class Announcement {
  private Integer announcement_id;
  private String title;
  private String content;
  private String creation_time;
  private String creator;

  public Announcement() {
  }

  public Announcement(Integer announcement_id, String title, String content, String creation_time, String creator) {
    this.announcement_id = announcement_id;
    this.title = title;
    this.content = content;
    this.creation_time = creation_time;
    this.creator = creator;
  }

  public Integer getAnnouncement_id() {
    return announcement_id;
  }

  public void setAnnouncement_id(Integer announcement_id) {
    this.announcement_id = announcement_id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public String getCreation_time() {
    return creation_time;
  }

  public void setCreation_time(String creation_time) {
    this.creation_time = creation_time;
  }

  public String getCreator() {
    return creator;
  }

  public void setCreator(String creator) {
    this.creator = creator;
  }

  @Override
  public String toString() {
    return "Announcement{" +
      "announcement_id=" + announcement_id +
      ", title='" + title + '\'' +
      ", content='" + content + '\'' +
      ", creation_time='" + creation_time + '\'' +
      ", creator='" + creator + '\'' +
      '}';
  }
}
