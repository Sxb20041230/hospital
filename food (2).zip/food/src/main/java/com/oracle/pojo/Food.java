package com.oracle.pojo;

// 表示具有bid、name、price和type的食物项
public class Food {
  String bid; // 食物项的唯一标识符
  String name; // 食物项的名称
  Integer price; // 食物项的价格
  String type; // 食物项的类型或类别

  // 默认构造函数
  public Food() {
  }

  // 带参数的构造函数
  public Food(String bid, String name, Integer price, String type) {
    this.bid = bid;
    this.name = name;
    this.price = price;
    this.type = type;
  }

  // bid的Getter和Setter方法
  public String getBid() {
    return bid;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  // name的Getter和Setter方法
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  // price的Getter和Setter方法
  public Integer getPrice() {
    return price;
  }

  public void setPrice(Integer price) {
    this.price = price;
  }

  // type的Getter和Setter方法
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  // 重写toString方法以提供表示Food对象的格式化字符串
  @Override
  public String toString() {
    return "Food{" +
      "bid='" + bid + '\'' +
      ", name='" + name + '\'' +
      ", price=" + price +
      ", type='" + type + '\'' +
      '}';
  }
}
