package com.oracle.mapper;

import com.oracle.pojo.Announcement;
import com.oracle.pojo.Food;

import java.util.List;


public interface NewsMapper {


  List<Announcement> selectAnnouncement();


  void insertAnnouncement(Announcement announcement);

}
