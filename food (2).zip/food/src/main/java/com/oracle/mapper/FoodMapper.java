package com.oracle.mapper;

import com.github.pagehelper.PageInfo;
import com.oracle.pojo.Food;

import java.util.List;

public interface FoodMapper {

  List<Food> selectFood();

  List<Food> selectAllFood();

  void deleteFood(String bid);

  void updateFood(Food food);

  void insertFood(Food food);

  Food selectAFood(String bid);
}
