package com.oracle.service;

import com.github.pagehelper.PageInfo;
import com.oracle.pojo.Announcement;
import com.oracle.pojo.Food;

import java.util.List;

public interface FoodService {

  PageInfo<Food> selectAllFood(Integer pageNum, Integer pageSize);

  void deleteFood(String bid);

  List<Food> selectFood();


  void updateFood(Food food);

  Food selectAFood(String bid);

  List<Announcement> selectAnnouncement();

  void insertAnnouncement(Announcement announcement);

}
