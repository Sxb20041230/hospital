package com.oracle.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.oracle.mapper.FoodMapper;
import com.oracle.mapper.NewsMapper;
import com.oracle.pojo.Announcement;
import com.oracle.pojo.Food;
import com.oracle.utils.DBUtils;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class FoodServiceImpl implements FoodService {

  @Override
  public PageInfo<Food> selectAllFood(Integer pageNum, Integer pageSize) {
    // 分页查询所有食物项
    PageHelper.startPage(pageNum, pageSize);
    SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
    FoodMapper foodMapper = sqlSession.getMapper(FoodMapper.class);
    List<Food> foodList = foodMapper.selectAllFood();
    sqlSession.close();
    return new PageInfo<Food>(foodList);
  }

  @Override
  public void deleteFood(String bid) {
    // 删除特定bid的食物项
    SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
    FoodMapper foodMapper = sqlSession.getMapper(FoodMapper.class);
    foodMapper.deleteFood(bid);
    sqlSession.commit(true);
    sqlSession.close();
  }

  @Override
  public List<Food> selectFood() {
    // 查询所有食物项
    SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
    FoodMapper foodMapper = sqlSession.getMapper(FoodMapper.class);
    List<Food> foodList = foodMapper.selectFood();
    sqlSession.close();
    return foodList;
  }

  @Override
  public void updateFood(Food food) {
    // 更新食物项信息
    SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
    FoodMapper foodMapper = sqlSession.getMapper(FoodMapper.class);
    foodMapper.updateFood(food);
    System.out.println(food);
    sqlSession.close();
  }

  @Override
  public Food selectAFood(String bid) {
    // 查询特定bid的食物项
    SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
    FoodMapper foodMapper = sqlSession.getMapper(FoodMapper.class);
    Food food = foodMapper.selectAFood(bid);
    return food;
  }



  @Override
  public List<Announcement> selectAnnouncement(){

    SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
    NewsMapper newsMapper = sqlSession.getMapper(NewsMapper.class);
    List<Announcement> announcementList = newsMapper.selectAnnouncement();
    sqlSession.close();
    return announcementList;
  }

  @Override
  public void insertAnnouncement(Announcement announcement) {
    SqlSession sqlSession = DBUtils.createDbUtils().getSQLSession();
    NewsMapper newsMapper = sqlSession.getMapper(NewsMapper.class);
    newsMapper.insertAnnouncement(announcement);
    sqlSession.commit();
    sqlSession.close();
    return;
  }
}
